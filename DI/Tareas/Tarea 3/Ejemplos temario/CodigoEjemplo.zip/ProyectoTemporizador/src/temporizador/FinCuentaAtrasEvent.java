
package temporizador;

import java.util.EventObject;

public class FinCuentaAtrasEvent extends EventObject{    
    public FinCuentaAtrasEvent(Object source) {
        super(source);
    }  
}
