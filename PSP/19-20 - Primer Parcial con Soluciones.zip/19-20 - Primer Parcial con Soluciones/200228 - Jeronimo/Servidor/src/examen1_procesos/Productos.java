
package examen1_procesos;

/**
 *
 * @author jjalv
 */
public class Productos {
    
    String precio;
    String nombre;
    String referencia;

    public Productos(String precio, String nombre, String referencia) {
        this.precio = precio;
        this.nombre = nombre;
        this.referencia = referencia;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }
    
    
    
}
